[nix-shell:~/projects/agent-trust]$ ./run.sh
INFO:     Will watch for changes in these directories: ['/home/daenaihax/projects/agent-trust']
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process [4057] using WatchFiles
INFO:     Started server process [4066]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     127.0.0.1:34910 - "GET /health HTTP/1.1" 200 OK
INFO:     127.0.0.1:34910 - "POST /registry/orgs HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/orgs HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/orgs/manufacturer/certificate HTTP/1.1" 200 OK
INFO:     127.0.0.1:34910 - "POST /registry/orgs/buyer/certificate HTTP/1.1" 200 OK
INFO:     127.0.0.1:34910 - "POST /registry/agents HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/agents HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/bindings HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/bindings/1/approve HTTP/1.1" 200 OK
INFO:     127.0.0.1:34910 - "POST /registry/bindings HTTP/1.1" 201 Created
INFO:     127.0.0.1:34910 - "POST /registry/bindings/2/approve HTTP/1.1" 200 OK
INFO:     127.0.0.1:34910 - "POST /policy/rules HTTP/1.1" 201 Created
INFO:     127.0.0.1:50086 - "POST /registry/agents HTTP/1.1" 409 Conflict
INFO:     127.0.0.1:50086 - "POST /auth/token HTTP/1.1" 200 OK
INFO:     ('127.0.0.1', 50090) - "WebSocket /broker/ws" [accepted]
INFO:     connection open
INFO:     127.0.0.1:50086 - "GET /broker/sessions?status=pending HTTP/1.1" 200 OK
INFO:     127.0.0.1:47556 - "POST /registry/agents HTTP/1.1" 409 Conflict
INFO:     127.0.0.1:47556 - "POST /auth/token HTTP/1.1" 200 OK
INFO:     127.0.0.1:47556 - "POST /broker/sessions HTTP/1.1" 201 Created
INFO:     127.0.0.1:47556 - "GET /broker/sessions HTTP/1.1" 200 OK
INFO:     127.0.0.1:47568 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/accept HTTP/1.1" 200 OK
INFO:     127.0.0.1:47556 - "GET /broker/sessions HTTP/1.1" 200 OK
INFO:     127.0.0.1:36348 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/messages HTTP/1.1" 202 Accepted
INFO:     ('127.0.0.1', 36358) - "WebSocket /broker/ws" [accepted]
INFO:     connection open
INFO:     127.0.0.1:47420 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/messages HTTP/1.1" 202 Accepted
INFO:     127.0.0.1:58332 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/messages HTTP/1.1" 202 Accepted
INFO:     127.0.0.1:58332 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/close HTTP/1.1" 200 OK
INFO:     connection closed
INFO:     127.0.0.1:58342 - "POST /broker/sessions/1e31e0a4-be47-48f9-a300-81d5d799ee00/close HTTP/1.1" 200 OK
INFO:     connection closed
^CINFO:     Shutting down
INFO:     Waiting for application shutdown.
INFO:     Application shutdown complete.
INFO:     Finished server process [4066]
INFO:     Stopping reloader process [4057]
(.venv) 
