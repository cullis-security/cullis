# Agent Trust Network — Presentazione del Progetto

## Il problema

Oggi gli agenti AI di organizzazioni diverse non hanno un modo standardizzato per comunicare in modo sicuro. Se un agente del buyer vuole parlare con un agente del manufacturer, chi garantisce che:

- l'agente sia chi dice di essere?
- l'organizzazione abbia autorizzato quella comunicazione?
- nessuno stia impersonando qualcuno o riproducendo messaggi vecchi?

Non esiste uno standard. Ogni integrazione è ad hoc, non auditabile, non federata.

---

## La soluzione

**Agent Trust Network** è un broker federato di fiducia inter-organizzativa per agenti AI — come ADFS, ma per LLM di aziende diverse.

Il broker garantisce:

| Garanzia | Come |
|---|---|
| Identità agente | Certificato x509 firmato dalla CA dell'organizzazione |
| Autorizzazione org | L'admin approva esplicitamente ogni agente (binding) |
| Scope controllato | Ogni sessione può usare solo le capability concesse |
| Non-ripudio | Audit log append-only su ogni evento |
| Anti-replay | JWT con jti univoco su ogni autenticazione |

---

## Architettura

```
Org A (buyer)                    Broker                   Org B (manufacturer)
─────────────                ─────────────────            ────────────────────
procurement-agent  ──────→   /auth/token (x509)  ←──────  sales-agent
                             /broker/sessions
                             /broker/ws (push)
                             /policy/rules
                             /registry/bindings
                             /db/audit
```

### PKI a tre livelli

```
Broker CA (RSA 4096)
├── Org CA manufacturer (RSA 2048)
│   └── sales-agent cert (RSA 2048)
└── Org CA buyer (RSA 2048)
    └── procurement-agent cert (RSA 2048)
```

Ogni agente possiede un certificato firmato dalla CA della propria organizzazione.
Il broker verifica la catena prima di emettere qualsiasi token.

---

## Demo — Supply Chain B2B

Due agenti Claude (`claude-sonnet-4-6`) negoziano un ordine d'acquisto attraverso il broker, senza mai comunicare direttamente.

### Flusso

| Step | Attore | Azione |
|---|---|---|
| 1 | Org admin | `bootstrap.py` — registra org, carica CA cert, approva binding |
| 2 | manufacturer | Avvia agente, autentica via x509, si mette in ascolto su WebSocket |
| 3 | buyer | Avvia agente, autentica via x509, apre sessione verso manufacturer |
| 4 | broker | Verifica policy session (buyer → manufacturer consentito) |
| 5 | manufacturer | Riceve notifica WS, accetta sessione |
| 6 | buyer → manufacturer | RFQ: richiesta offerta formale (prodotto, quantità, termini) |
| 7 | manufacturer → buyer | Offerta completa (disponibilità, prezzo scontato, lead time, pagamento) |
| 8 | buyer → manufacturer | ORDINE CONFERMATO + riepilogo + FINE |
| 9 | entrambi | Close sessione (idempotente), WebSocket chiuso |

### Risultato demo

- Autenticazione x509 riuscita su entrambi gli agenti
- Sessione aperta, accettata e chiusa senza errori
- Negoziazione completata in 2 turni
- Audit log completo su ogni evento

---

## Target

Settori regolamentati dove tracciabilità e autenticazione inter-organizzativa sono requisiti:

- **Logistica** — ordini automatizzati tra supplier e distributor
- **Banche / KYC** — agenti che si scambiano dati verificati tra istituti
- **Sanità** — comunicazione tra sistemi clinici di ospedali diversi

---

## Stato del progetto

| Area | Stato |
|---|---|
| Broker base + JWT RS256 | Completato |
| Registry org + binding + scope | Completato |
| Policy engine (session + message) | Completato |
| WebSocket push | Completato |
| Agenti Claude reali | Completato |
| PKI x509 + autenticazione certificati | Completato |
| Test suite | 42/42 passing |
| Blacklist jti (replay completo) | In roadmap |
| Sessioni persistenti | In roadmap |
| Rate limiting | In roadmap |
| Detection prompt injection | In roadmap |

---

## Log demo

| File | Contenuto |
|---|---|
| `06_demo_certs.md` | Generazione PKI da zero |
| `06_demo_bootstrap.md` | Onboarding organizzazioni e agenti |
| `06_demo_broker.md` | Log broker uvicorn durante la demo |
| `06_demo_manufacturer.md` | Output agente manufacturer (responder) |
| `06_demo_buyer.md` | Output agente buyer (initiator) |
