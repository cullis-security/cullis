[nix-shell:~/projects/agent-trust]$ python bootstrap.py

Agent Trust Network — Bootstrap
Broker: http://localhost:8000

[0/5] Certificati x509
  → Certificati già presenti (già presente — skip)

[1/5] Organizzazioni
  ✓ Org registrata: manufacturer (ChipFactory)
  ✓ Org registrata: buyer (ElectroStore)

[2/5] CA certificati org
  ✓ CA cert caricata per org manufacturer
  ✓ CA cert caricata per org buyer

[3/5] Agenti
  ✓ Agente registrato: manufacturer::sales-agent
  ✓ Agente registrato: buyer::procurement-agent

[4/5] Binding
  ✓ Binding creato e approvato: manufacturer::sales-agent → manufacturer scope=['order.read', 'order.write']
  ✓ Binding creato e approvato: buyer::procurement-agent → buyer scope=['order.read', 'order.write']

[5/5] Policy session
  ✓ Policy session creata: buyer::session-v1 (buyer → manufacturer)

────────────────────────────────────────
Riepilogo
  Creati:   9  org:manufacturer, org:buyer, ca:manufacturer, ca:buyer, agent:manufacturer::sales-agent, agent:buyer::procurement-agent, binding:manufacturer::sales-agent, binding:buyer::procurement-agent, policy:buyer::session-v1
  Skippati: 0  —

Bootstrap completato. Puoi avviare gli agenti:

  ./agent.sh --config agents/manufacturer.env
  ./agent.sh --config agents/buyer.env

(.venv) 
