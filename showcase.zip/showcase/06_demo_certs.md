[nix-shell:~/projects/agent-trust]$ python generate_certs.py

Agent Trust Network — Generazione certificati

[1/3] Broker CA
  ✓  broker CA generata

[2/3] Org CA + certificati agenti
  ✓  manufacturer org CA generata
  ✓  manufacturer::sales-agent cert generato
  ✓  buyer org CA generata
  ✓  buyer::procurement-agent cert generato

Certificati pronti in /home/daenaihax/projects/agent-trust/certs

  manufacturer/manufacturer__sales-agent.pem
  manufacturer/manufacturer__sales-agent-key.pem
  buyer/buyer__procurement-agent.pem
  buyer/buyer__procurement-agent-key.pem
(.venv) 
